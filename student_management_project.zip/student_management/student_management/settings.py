SECRET_KEY='dummy'
INSTALLED_APPS=['students']